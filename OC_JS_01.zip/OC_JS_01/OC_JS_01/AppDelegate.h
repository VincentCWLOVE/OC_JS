//
//  AppDelegate.h
//  OC_JS_01
//
//  Created by vincent on 16/2/25.
//  Copyright © 2016年 Vincent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

