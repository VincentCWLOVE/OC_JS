//
//  ViewController.m
//  OC_JS_01
//
//  Created by vincent on 16/2/25.
//  Copyright © 2016年 Vincent. All rights reserved.
//

#import "ViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@protocol jSObjDelegate <JSExport>

-(void)callCamera;


@end

@interface ViewController ()<UIWebViewDelegate,jSObjDelegate>

@property (nonatomic,strong)JSContext *jsContext;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    webView.delegate = self;
    [self.view addSubview:webView];
    
    NSString *htmlPath = [[NSBundle mainBundle] pathForResource:@"demo" ofType:@"html"];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:htmlPath]]];
    
   NSString *webTitle = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    NSString *url = [webView stringByEvaluatingJavaScriptFromString:@"document.location.href"];
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    self.jsContext = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    self.jsContext[@"vincent"] = self;
    self.jsContext.exceptionHandler = ^(JSContext *context,JSValue *exceptionValue){
        NSLog(@"异常信息 ： %@",exceptionValue);
    };
    NSLog(@"%@",self.jsContext);
}

#pragma mark ----

-(void)callCamera{
    NSLog(@"调用系统相机");
    
    JSValue *picCallBack = self.jsContext[@"getPhotoFromOC"];
    [picCallBack callWithArguments:@[@"照片"]];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
