//
//  main.m
//  OC_JS_01
//
//  Created by vincent on 16/2/25.
//  Copyright © 2016年 Vincent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
